import collections
import os

def ItemPurchasedCounter():
    print(os.getcwd())
    with open('GroceryList.txt') as fp:
        counts = collections.Counter(line.strip() for line in fp)
    for key in counts:
        print('%s %d' % (key, counts[key]))
    

def SpecificItemPurchasedCounter(v):
    v = v.capitalize()
    with open('GroceryList.txt') as fp:
        data = fp.read()
        occurences = data.count(v)
        return occurences
    
def Histogram():
    with open('frequency.dat', "w") as wp:    
        with open('GroceryList.txt') as fp:
            counts = collections.Counter(line.strip() for line in fp)
        for key in counts:
            wp.write('%s %d\n' % (key, counts[key]))
 