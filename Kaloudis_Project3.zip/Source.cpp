#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>

using namespace std;
/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyRun_SimpleString("import sys\nsys.path.append(\".\")\n");
	PyObject* my_module = PyImport_ImportModule("Grocery");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	PyRun_SimpleString("import sys\nsys.path.append(\".\")\n");
	// Build the name object
	pName = PyUnicode_FromString((char*)"Grocery");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	PyRun_SimpleString("import sys\nsys.path.append(\".\")\n");
	// Build the name object
	pName = PyUnicode_FromString((char*)"Grocery");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}
void displayHist() {
	// read file
	//    name
	//    freq
	string filename = "frequency.dat";
	ifstream iFile(filename);
	string product;
	int freq;

	while (!iFile.eof()) {
		iFile >> product >> freq;
		cout << product << " ";

		for (int i = 0; i < freq; i++) {
			cout << "*";
		}

		// add a new line
		cout << endl;  // to give space
	}

}
void DisplayMenu() {
	cout << "What would you like to do?" << endl;
	cout << "1) Produce a list of all items purchased in a given day along with the number of times each item was purchased." << endl;
	cout << "2) Produce a number representing how many times a specific item was purchased in a given day." << endl;
	cout << "3) Produce a text - based histogram listing all items purchased in a given day, along with a representation of the number of times each item was purchased." << endl;
	cout << "4) Exit" << endl;
	cout << "Enter your selection as 1, 2, 3, or 4" << endl;
}

void UserChoice() {
	int choice;
	string item;

	cin >> choice;

	if (choice == 1) {
		cout << "Printing list of items purchased and how many times each item was purchased" << endl;
		CallProcedure("ItemPurchasedCounter");
		cout << endl;
		return;
	}
	else if (choice == 2) {
		cout << "Please enter the item name." << endl;
		cin >> item;
		cout << item << ": " << callIntFunc("SpecificItemPurchasedCounter", item) << endl;
		return;
	}
	else if (choice == 3) {
		cout << "Creating text based histogram." << endl;
		CallProcedure("Histogram");
		cout << endl;
		displayHist();
	}
	else if (choice == 4) {
		cout << "Exiting program. Goodbye." << endl;
		exit(0);  // exits program
	}
	else {
		cout << "Invalid option. Please enter your selection as 1, 2, 3, or 4." << endl;
	}

}

/*
Write C++ code to read the frequency.dat file and display a histogram. Loop through the newly created file and read the name and frequency on each row. Then print the name, followed by asterisks or another special character to represent the numeric amount. The number of asterisks should equal the frequency read from the file. For example, if the file includes 4 potatoes, 5 pumpkins, and 3 onions then your text-based histogram may appear as represented below. However, you can alter the appearance or color of the histogram in any way you choose.
Potatoes ****
Pumpkins *****
Onions ***
*/


int main() {
	while (1)
	{
		DisplayMenu();
		UserChoice();
	}
	return 0;
}